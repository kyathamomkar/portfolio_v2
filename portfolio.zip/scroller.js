$('.wrapper').bind('mousewheel', function(e){
		
        if(e.originalEvent.wheelDelta /120 > 0) {
			e.preventDefault();
        //  $('.wrapper').animatescroll({scrollSpeed:100,easing:'easeOutQuart'});
        }
        else{  
            $('.galaxywrap').animatescroll({scrollSpeed:100,easing:'easeOutQuart'});
			
			/* mouse color */
		$(".mouse").css("border","2px solid #1b3592");
		$(".mouse-button").css("background-color","#1b3592");
		$(".spaceshipmain").addClass("animate__zoomInUp");
		/* removing classes in galaxy*/
		$(".spaceshipmain").removeClass("animate__fadeOutBottomLeft");
			
        }
    });

 $('.galaxywrap').bind('mousewheel', function(e){	
        if(e.originalEvent.wheelDelta /120 > 0) {
// console.log('scrolling up !');
		e.preventDefault();
          $('.wrapper').animatescroll({scrollSpeed:100,easing:'easeOutQuart'});
		
		/* mouse color and removing some clas on space ship */
		 $(".mouse").css("border","2px solid #000000");
		$(".mouse-button").css("background-color","#000000");
		$(".spaceshipmain").addClass("animate__fadeOutBottomLeft"); 
		
		/*removing classes */
		$(".spaceshipmain").removeClass("animate__zoomInUp");
			
        }
        else{
   // console.log('scrolling down !');
}
});