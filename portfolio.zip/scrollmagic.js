var controller = new ScrollMagic.Controller({addIndicators: false}); 
TweenLite.defaultEase = Linear.easeNone;
var Elastic = Elastic.easeOut.config(2.5, 1);
var tween1 = TweenMax.to("#reveal1", 1, {className: "+=hide"});  
new ScrollMagic.Scene({
							triggerElement: "#trigger1", 
							duration: "100%",
							offset:  300
						})
						.setTween(tween1)
						//.addIndicators()
						.addTo(controller);

//text intro animation
var tween2 = TweenMax.to(".intro", 1, {className: "+=tracking-in-contract-bck"});  
new ScrollMagic.Scene({
							triggerElement: "#introsvg",
							duration: "40",
							offset: -303
						})
						.setTween(tween2)
						//.addIndicators() 
						.addTo(controller);

//thinkdiv animation
var thinkdivTween = TweenMax.to(".thinklogo", 1, {className: "+=animate__fadeInUp"});  
new ScrollMagic.Scene({
							triggerElement: ".thinkdiv",
							duration: "0",
							offset: 50
						})
						.setTween(thinkdivTween)
						//.addIndicators() 
						.addTo(controller);

//background change to white
var timeline1 = new TimelineMax({ defaults: {duration: 0, ease: "power4.out"} } );
var tween3 = TweenMax.to(".bada", 0.5,{opacity:0,  ease: "slow(0.1, 0.7, false)"}, 0);  
var tween4 = TweenMax.to("body", 0.5, {ease:Cubic.easeIn,backgroundColor: "rgb(239 233 233)"}, 0);
var tween5 = TweenMax.to(".cleanhandsText", 1, {className: "+=cleantextAnimation"}, 0.2);
var tweenAppear = TweenMax.to(".cleancovid", 1, {opacity:1,  transform:  "matrix(1, 0, 0, 1, 150, 0)"},0);
var tweenChangeFontColor = TweenMax.to(".intro", 0.1, {fill:"black"},0);
timeline1.add(tween3).add(tween4).add(tween5).add(tweenAppear).add(tweenChangeFontColor);
new ScrollMagic.Scene({
							triggerElement: ".svgtrigger",
							duration: "0",
							offset: -300
						})
						.setTween(timeline1)  
						//.addIndicators() 
						.addTo(controller);

var tween6 = TweenMax.to(".handsdiv", 1,{opacity:1, transform: "translate3d(0, 0,0)"});  
new ScrollMagic.Scene({
							triggerElement: ".cleancovid",
							duration: "200",
							offset: -50
						})
						.setTween(tween6)  
						//.addIndicators() 
						.addTo(controller);

var moveCircleOver = TweenMax.to(".svgtrigger", 5,{ ease:Linear.easeOut, transform: "translate3d(0,-150px,0)"});
new ScrollMagic.Scene({
							triggerElement: ".svgtrigger",
							duration: "500",
							offset: -240
						})
						.setTween(moveCircleOver)  
						//.addIndicators() 
						.addTo(controller);

var timeline2 = new TimelineMax({ defaults: {duration: 1, ease: "Linear.easeOut"} });
var tween7 = TweenMax.to(".withoutcircle", 10,{ opacity:0.7, ease:Linear.easeOut, transform: "translate3d(0,-50px,0)"},0);
var tween8 = TweenMax.to(".topcircle", 	20,{ ease:Linear.easeOut, borderRadius: "0%"}, 10);
timeline2.add(tween7).add(tween8);
new ScrollMagic.Scene({
							triggerElement: ".cleancovid",
							duration: "300",
							offset: 200
						})
						.setTween(timeline2)  
						//.addIndicators() 
						.addTo(controller);

var tween9 = TweenMax.to(".goodjobtext", 1,{className: "+=animate__fadeInUp slideintext"});
new ScrollMagic.Scene({
							triggerElement: ".goodboydiv",
							duration: "100",
							offset: -100
						})
						.setTween(tween9)  
						//.addIndicators({name:"goodJob"}) 
						.addTo(controller);

var movebottomCircleOver = TweenMax.to(".bottomcircle", 5,{ ease:Linear.easeOut, transform: "translate3d(0,-150px,0)"});
new ScrollMagic.Scene({
							triggerElement: ".goodboydiv",
							duration: "500",
							offset: 0
						})
						.setTween(movebottomCircleOver)  
						//.addIndicators() 
						.addTo(controller);

var bottomcircleRadius = TweenMax.to(".bottomcircle", 1,{ ease:Linear.easeOut, borderRadius: "0%",backgroundColor:"#e3dacd"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle",
							duration: "100",
							offset: 300
						})
						.setTween(bottomcircleRadius)  
						//.addIndicators() 
						.addTo(controller);

var circlepicscale = TweenMax.to(".circlepic", 1,{ ease:Linear.easeOut,filter:"blur(0px)", borderRadius: "0% 30%",
	boxShadow: "0 10px 25px hsla(0,0%,0%,0.5)"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle",
							duration: "100",
							offset: 300
						})
						.setTween(circlepicscale)  
						//.addIndicators() 
						.addTo(controller);

var targetpicrotate = TweenMax.to(".targetpic", 1,{ ease:Linear.easeOut, transform: "rotate(-90deg)"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle",
							duration: "300",
							offset: 300
						})
						.setTween(targetpicrotate)  
						//.addIndicators() 
						.addTo(controller);

var iframeOpacity = TweenMax.to(".treeiframe", 1,{ ease:Linear.easeOut, opacity:1 },0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle",
							duration: "100",
							offset: 300
						})
						.setTween(iframeOpacity)  
						//.addIndicators() 
						.addTo(controller);


var circlepicrotate = TweenMax.to(".circlepic", 20,{ ease:Linear.easeOut,transform: "translate3d(0px, -200px, 0px) rotate(-10deg) scale(1.5)"},0);
new ScrollMagic.Scene({
							triggerElement: ".goodboydiv",
							duration: "1000",
							offset: 0
						})
						.setTween(circlepicrotate)  
						//.addIndicators() 
						.addTo(controller);

//svg path
function pathPrepare ($el) {
var lineLength = $el[0].getTotalLength();
$el.css("stroke-dasharray", lineLength);
$el.css("stroke-dashoffset", lineLength);
}

var $yearline = $("path#yearline"); 
var bezierData = [{x: -5, y: 0}
,{x: 298.3333333333333, y: 153.33333333333331}
,{x: 400, y: 303.33333333333337}
,{x: 300, y: 450}
,{x: 200, y: 596.6666666666666}
,{x: 143.33333333333334, y: 696.6666666666666}
,{x: 130, y: 750}
,{x: 110, y: 816.6666666666666}
,{x: 166.66666666666669, y: 900}
,{x: 300, y: 1000}
,{x: 433.3333333333333, y: 1100}
,{x: 383.3333333333333, y: 1166.6666666666667}
,{x: 150, y: 1200}];
// prepare SVG
pathPrepare($yearline); 

TweenLite.set(".ball", {xPercent:-50, yPercent:-50});

var yearTimeline = new TimelineMax();
yearTimeline.to(".ball1",0.01, {autoAlpha:1},0);
yearTimeline.to($yearline, 1, {strokeDashoffset: 0}, 0); 
yearTimeline.to($yearline, 1, {stroke: "#33629c"}, 0);
yearTimeline.to(".ball1", 1, {bezier: {values:bezierData, type:"cubic" }, ease:Linear.easeInOut},0);
yearTimeline.to(".ball2, .text1",0.05,{autoAlpha:1, scale:2, transformOrigin:"center", ease:Elastic},0.19);
yearTimeline.to("#canvas",0.05,{autoAlpha:0.3, ease:Linear.easeOut},0.19);
yearTimeline.to(".ball3, .text2",0.05,{autoAlpha:1, scale:2, transformOrigin:"center", ease:Elastic },0.31);
yearTimeline.to(".ball4, .text3",0.05,{autoAlpha:1, scale:2, transformOrigin:"center", ease:Elastic},0.48);

var yearscene = new ScrollMagic.Scene({triggerElement: "#pathsvgtrigger", duration: "1800",offset: 200})
							.setTween(yearTimeline)
							//.addIndicators({name:"svgAnim"})
							.addTo(controller);
yearscene.on("progress", function (event) {
    //console.log("Scene progress: " + event.progress);
});


var movecanvasdown = TweenMax.to("#canvas", 1,{ ease:Linear.easeOut , transformOrigin:"center",transform: "translate3d(0, 250px,0) scale(1.2)"});
new ScrollMagic.Scene({
							triggerElement: "#canvas",
							duration: "300",
							offset: 500
						})
						.setTween(movecanvasdown)  
						//.addIndicators({name:"movecanvasdown"})
						.addTo(controller);



var movebottom2CircleOver = TweenMax.to(".bottomcircle2", 5,{ ease:Linear.easeOut, transform: "translate3d(0,-150px,0)"});
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle2",
							duration: "500",
							offset: 0
						})
						.setTween(movebottom2CircleOver)  
						//.addIndicators({name:"moveC2Over"})
						.addTo(controller);

var changecircleback2white = TweenMax.to(".bottomcircle", 5,{ ease:Linear.easeOut, backgroundColor: "rgba(239, 233, 233,1)"});
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle2",
							duration: "400",
							offset: 0
						})
						.setTween(changecircleback2white)  
						//.addIndicators({name:"whiteBGstart"}) 
						.addTo(controller);

var bottomcircle2Radius = TweenMax.to(".bottomcircle2", 1,{ ease:Linear.easeOut, borderRadius: "0%"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle2",
							duration: "100",
							offset: 400
						})
						.setTween(bottomcircle2Radius)  
						//.addIndicators({name:"circle2radius"})  
						.addTo(controller);

var c2BG = TweenMax.to(".bottomcircle2, .svgtrigger", 1,{className:"+=bottomc2BG"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle2",
							duration: "1",
							offset: 540
						})
						.setTween(c2BG)  
						//.addIndicators({name:"c2BG"})  
						.addTo(controller);



var movebottom3CircleOver = TweenMax.to(".bottomcircle3", 5,{ ease:Linear.easeOut, transform: "translate3d(0,-350px,0)"});
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle3",
							duration: "500",
							offset: -300
						})
						.setTween(movebottom3CircleOver)  
						//.addIndicators({name:"moveC3Over"})
						.addTo(controller);

var bottomcircle3Radius = TweenMax.to(".bottomcircle3", 1,{ ease:Linear.easeOut, borderRadius: "0%",backgroundColor:"#303030"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle3",
							duration: "50",
							offset: 400
						})
						.setTween(bottomcircle3Radius)  
						//.addIndicators({name:"c3radius"})  
						.addTo(controller);

var tablecolor = TweenMax.to(".projectheading", 1,{  color:"#e6e2dd", backgroundImage:"linear-gradient(#303030,  #303030)"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle3",
							duration: "100",
							offset: 400
						})
						.setTween(tablecolor)  
						//.addIndicators({name:"tablecolor"})  
						.addTo(controller);

var projectstext = TweenMax.to(".projectstext", 1,{ ease:Linear.easeOut,color:"#e6e2dd", opacity:0.3},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle3",
							duration: "50",
							offset: 400
						})
						.setTween(projectstext)  
						//.addIndicators({name:"projectstext"})  
						.addTo(controller);

var tableheading = TweenMax.to(".projectstable , .projectheading", 1,{ border:"1px solid #e6e2dd"},0);
new ScrollMagic.Scene({
							triggerElement: ".bottomcircle3",
							duration: "50",
							offset: 400
						})
						.setTween(tableheading)  
						//.addIndicators({name:"tableheading"})  
						.addTo(controller);
 
var svgColor = TweenMax.to(".svgtrigger , .bada", 1,{opacity:1, background: "linear-gradient(to right,#d5d2c6, #c5b47c)"},0);
new ScrollMagic.Scene({
							triggerElement: ".morework",
							duration: "0",
							offset: -150
						})
						.setTween(svgColor)  
						//.addIndicators({name:"svgColor"})  
						.addTo(controller); 

 var moveCollaup = TweenMax.to(".collaborate", 1,{ease:Linear.easeOut,opacity:1},0);
new ScrollMagic.Scene({
							triggerElement: ".morework",
							duration: "0",
							offset: 100
						})
						.setTween(moveCollaup)  
						//.addIndicators({name:"moveCollaup"})  
						.addTo(controller);  