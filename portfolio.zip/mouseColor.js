function isInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)

    );
}
 
const galaxycenter = document.querySelector('.galaxycenter');
const logo = document.querySelector('.slide'); 	
 
document.addEventListener('scroll', function () {
	/* if user is in galaxy part */
    if(isInViewport(galaxycenter))
	{
		$(".mouse").css("border","2px solid #1b3592");
		$(".mouse-button").css("background-color","#1b3592");
		$(".spaceshipmain").addClass("animate__zoomInUp");
		/* removing classes in galaxy*/
		$(".spaceshipmain").removeClass("animate__fadeOutBottomLeft");
		
	}
	/* if user is in first page part */
	else if(isInViewport(logo))
    {
		$(".mouse").css("border","2px solid #000000");
		$(".mouse-button").css("background-color","#000000");
		$(".spaceshipmain").addClass("animate__fadeOutBottomLeft"); 
		
		/*removing classes */
		$(".spaceshipmain").removeClass("animate__zoomInUp");
	}
 
}, {
    passive: true
}); 