var clog = console.log;

var BLUE, RED;
var theta;

function setup() {
    createCanvas(windowWidth, windowHeight);

    BLUE = color('#e3dacd');
    RED = color('#c8b69d');

    stroke(RED);
}

function draw() {
    background(BLUE);
	frameRate(60);
    translate(width / 2, height);
    let a = (mouseY / height) * 90;
    theta = radians(a);
    branch(height/4);
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}

function branch(len) {
    line(0, 0, 0, -len);
    translate(0, -len);

    len *= 0.66;

    if (len > 2) {
        push();
        rotate(theta);
        branch(len);
        pop();

        push();
        rotate(-theta);
        branch(len);
        pop();
    }
}