//var $svg = $('.mysvg').drawsvg({duration:10000, callback: function() {
//       $('.svgg').css({ fill: "red" });
//      }});

//$svg.drawsvg('animate');

var $doc = $(document),
    $win = $(window),
    $svg = $('.thinksvg').drawsvg(),
    max = $doc.height() - $win.height();

$win.on('scroll', function() {
  var p = ($win.scrollTop() / max)*2;
  //console.log(p);
  $svg.drawsvg('progress', p);
	if(p>0.5)
		{
 $('.thinksvgg').css({ fill: "#5b84b2"});
		}
	else{
		$('.thinksvgg').css({ fill: "none" });
	}
});

  /*
var $circle = $('#canvas');

function moveCircle(e) {
	TweenLite.to($circle, 2, {
    css: { 	
left: e.pageX,
top: e.pageY
    }
  });
}

$(window).on('mousemove', moveCircle);   */