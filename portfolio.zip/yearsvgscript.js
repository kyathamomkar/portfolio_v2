function pathPrepare ($el) {
var lineLength = $el[0].getTotalLength();
$el.css("stroke-dasharray", lineLength);
$el.css("stroke-dashoffset", lineLength);
}

var $yearline = $("path#yearline"); 

// prepare SVG
pathPrepare($yearline); 

// init controller
var controller = new ScrollMagic.Controller();

// build tween
var yeartween = new TimelineMax()
.add(TweenMax.to($yearline, 0.9, {strokeDashoffset: 0, ease:Linear.easeNone})) // draw word for 0.9
.add(TweenMax.to($yearline, 1, {stroke: "#33629c", ease:Linear.easeNone}), 0);			// change color during the whole thing

// build scene
var yearscene = new ScrollMagic.Scene({triggerElement: "#pathsvgtrigger", duration: "2000", tweenChanges: true})
.setTween(yeartween)
.addIndicators() // add indicators (requires plugin)
.addTo(controller);